﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VegetableNinja.Contracts
{
    using Models.Vegetables;

    public interface IBlankSpace : IGameObject
    {
    }
}
