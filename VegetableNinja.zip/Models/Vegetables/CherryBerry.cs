﻿namespace VegetableNinja.Models.Vegetables
{
    public class CherryBerry : Vegetable
    {
        public CherryBerry()
            : base('C', 0, 10, 5)
        {
        }
    }
}