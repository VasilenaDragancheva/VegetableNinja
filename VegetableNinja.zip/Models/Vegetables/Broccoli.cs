﻿namespace VegetableNinja.Models.Vegetables
{
    public class Broccoli : Vegetable
    {
        public Broccoli()
            : base('B', 10, 0, 3)
        {
        }
    }
}