﻿namespace VegetableNinja.Models.Vegetables
{
    public class Asparagus : Vegetable
    {
        public Asparagus()
            : base('A', 5, -5, 2)
        {
        }
    }
}