﻿namespace VegetableNinja.Contracts
{
    public class Mushroom : Vegetable
    {
        public Mushroom()
            : base('M', -10, -10, 5)
        {
        }
    }
}