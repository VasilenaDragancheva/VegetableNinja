﻿namespace VegetableNinja.Models.Vegetables
{
    public class Royal : Vegetable
    {
        public Royal()
            : base('R', 20, 10, 10)
        {
        }
    }
}